
#include "Comment.h"

Comment::Comment
(std::string arg_profile_id, std::string arg_post_id, std::string arg_comment_id,
 Person * arg_author, Message * arg_msg, JvTime * arg_created)
{
  this->profile_id = arg_profile_id;
  this->post_id = arg_post_id;
  this->comment_id = arg_comment_id;
  this->author = arg_author;
  this->msg = arg_msg;
  this->created = arg_created;

  // very critical ==> portable to different platforms
  this->reactions = NULL;
}

Json::Value * Comment::dumpJ
(void)
{
  // to be implemented for hw4 part3
  return (Json::Value *) NULL; // this line is incorrect, just to avoid a g++ warning
}
