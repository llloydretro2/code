Haosen Cao 918158439

Instruction:
cd <dictionary_name>
make

Usage for mybreak and myheal:
./mybreak <source_file> <break_prefix> <size of each chunk in 1K>
./myheal <new file name created by myheal> <break_prefix> <size of each chunk in 1K> <number of chunks previously being divided into>