
// f2021 version of HW2 part2

#include "Person.h"

GPS_DD::GPS_DD()
{
  // finished
  this->latitude = 0.0;
  this->longitude = 0.0;
}

GPS_DD::GPS_DD(double arg_latitude, double arg_longitude)
{
  // finished
  this->latitude = arg_latitude;
  this->longitude = arg_longitude;
}

double 
GPS_DD::getLatitude()
{
  // finished
  return this->latitude;
}
 
double
GPS_DD::getLongitude
()
{
  // finished
  return this->longitude;
}

// DD distance calculation
#include <math.h>
#define pi 3.14159265358979323846

double deg2rad(double);
double rad2deg(double);

double GeoDataSource_distance(double lat1, double lon1, double lat2, double lon2, char unit) 
{
  // to be implemented by the student
  // for this homework, please use the source code shared by GeoDataSource under --
  // https://www.geodatasource.com/developers/c (you can copy and paste here)
}

double deg2rad(double deg)
{
  // finished
  return (deg * pi / 180);
}

double rad2deg(double rad)
{
  // finished
  return (rad * 180 / pi);
}

double
GPS_DD::distance
(GPS_DD& another)
{
  // to be implemented by the student
  // something like: return GeoDataSource_distance(,,,,);
}

IP_Address::IP_Address()
{
  // do nothing here for now
}

IP_Address::IP_Address
(unsigned int arg_ip)
{
  // do nothing here for now
}

std::string SDefault {"Default"};

std::string&
IP_Address::getIPaddressString()
{  
  // do nothing here for now
  // std::string s {"0.0.0.0"};
  // return s;
}

unsigned int
IP_Address::getIPaddressValue()
{
  // do nothing here for now
  return 0;
}

Person::Person()
{
  // to be implemented by the student
}

Person::Person
(std::string arg_name, std::string arg_id)
{
  // to be implemented by the student
}

void
Person::setHome
(std::string arg_home)
{
  // to be implemented by the student
}

void
Person::setHome
(GPS_DD arg_home)
{
  // to be implemented by the student
}

std::string
Person::getVsID()
{
  // to be implemented by the student
}

std::string
Person::getName()
{
  // to be implemented by the student
  return name;
}

bool
Person::operator==
(Person& aPerson)
{
  // to be implemented by the student
}
