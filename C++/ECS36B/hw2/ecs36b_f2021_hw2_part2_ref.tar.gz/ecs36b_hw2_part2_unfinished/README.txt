// run      -- make
// then run -- ./ecs36b_hw2_testing 169.237.6.102 95837 <your vsID>
