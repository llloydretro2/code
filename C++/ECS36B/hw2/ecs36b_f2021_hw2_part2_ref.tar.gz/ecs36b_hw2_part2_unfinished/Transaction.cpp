
#include "Transaction.h"

// this line is important -- try to remove it and see what happens.
unsigned int Transaction::transaction_count { };

Transaction::Transaction(unsigned int arg_type)
{
  // to be implemented by the student
}

Transaction::Transaction
(unsigned int arg_type, Person& arg_sender, Person& arg_receiver,
 GPS_DD& arg_src_where, GPS_DD& arg_dst_where,
 IP_Address& arg_srcIP, IP_Address& arg_dstIP, time_t arg_when)
{
  // to be implemented by the student
}

void
Transaction::setData(void *arg_data)
{
  // to be implemented by the student
}

void *
Transaction::getData(void)
{
  // to be implemented by the student
}

double
Transaction::getDistance()
{
  // to be implemented by the student
}

std::string
Transaction::description()
{
  // finished
  std::string res;

  if (this->tr_sender == this->tr_receiver)
    {
      res += ("One-person Transaction for " + this->tr_sender.getName());
    }
  else
    {
      res += ("Two-persons Transaction for " + this->tr_sender.getName() + " and " + this->tr_receiver.getName());
    }

  res += (", Distance = " + std::to_string(this->getDistance()) + " miles.");
  return res;
}
