
// for Json::value
#include <json/json.h>
#include <json/reader.h>
#include <json/writer.h>
#include <json/value.h>
#include <string>
#include <ctype.h>

// for JsonRPCCPP
#include <iostream>
#include "hw7server.h"
#include <jsonrpccpp/server/connectors/httpserver.h>
#include <stdio.h>

// ecs36b_hw7
#include "Post.h"

std::map<std::string, Post *> Post_Map;
std::map<std::string, JvTime *> RT_Map;

extern const char *hw5error[];

using namespace jsonrpc;
using namespace std;

class Myhw7Server : public hw7Server
{
public:
  Myhw7Server(AbstractServerConnector &connector, serverVersion_t type);
  virtual Json::Value update(const std::string& updating_json);
  virtual Json::Value search(const std::string& search_clause);
};

Myhw7Server::Myhw7Server(AbstractServerConnector &connector, serverVersion_t type)
  : hw7Server(connector, type)
{
  std::cout << "Myhw7Server Object created" << std::endl;
}

// member functions

int
checkTimeInterval
(std::string arg_id)
{
  time_t ticks; 
  ticks = time(NULL);
  struct std::tm * my_tm_ptr = gmtime(&ticks);
  JvTime * now_time_ptr = new JvTime();
  int rc = now_time_ptr->setStdTM(my_tm_ptr);
  if (rc != HW5_ERROR_NORMAL)
    {
      std::cout << "error: failed to set time!" << std::endl;
      delete now_time_ptr;
      return HW5_ERROR_SET_STD_TM;
    }
  
  if (RT_Map.find(arg_id) == RT_Map.end())
    {
      RT_Map[arg_id] = now_time_ptr;
      return HW5_ERROR_NORMAL;
    }

  double time_diff = 0.0;
	  
  // Now we should check the timestamp
  JvTime *old_time_ptr = RT_Map[arg_id];

  time_diff = (*now_time_ptr) - (*old_time_ptr);
  delete old_time_ptr;
  RT_Map[arg_id] = now_time_ptr;

  std::cout << "Time_Diff = " << time_diff << std::endl;
  if (time_diff < 5.0)
    {
      return HW5_ERROR_SMACK_STACK_DETECTED;
    }
  return HW5_ERROR_NORMAL;
}

Json::Value
Myhw7Server::update(const std::string& updating_json)
{
  Post * post_ptr = NULL;

  /* to be implemented by ecs36b f2020 */

  Json::Value *rj_ptr = post_ptr->dumpJ();
  return (*rj_ptr);
}

Json::Value
Myhw7Server::search
(const std::string& search_clause)
{
  Json::Value result_json;

  /* to be implemented by ecs36b f2020 */

  return result_json;
}

int
main(int argc, char *argv[])
{
  if (argc != 1) exit(-1);

  char buf[1024];
  int flag1;

  HttpServer httpserver(55407);
  Myhw7Server s(httpserver,
		JSONRPC_SERVER_V1V2); // hybrid server (json-rpc 1.0 & 2.0)
  s.StartListening();
  std::cout << "Hit enter to stop the server" << endl;
  getchar();

  s.StopListening();
  return 0;
}
